package com.dexterous.flutterlocalnotifications;

import androidx.annotation.Keep;
@Keep
/* loaded from: classes.dex */
public enum RepeatInterval {
    EveryMinute,
    Hourly,
    Daily,
    Weekly
}
