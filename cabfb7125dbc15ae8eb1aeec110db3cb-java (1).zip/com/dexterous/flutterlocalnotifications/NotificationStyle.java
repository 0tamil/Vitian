package com.dexterous.flutterlocalnotifications;

import androidx.annotation.Keep;
@Keep
/* loaded from: classes.dex */
public enum NotificationStyle {
    Default,
    BigPicture,
    BigText,
    Inbox,
    Messaging,
    Media
}
