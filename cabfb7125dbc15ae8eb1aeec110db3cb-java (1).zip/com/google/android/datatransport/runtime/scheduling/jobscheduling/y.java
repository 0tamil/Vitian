package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import f.b.a.a.i.p;
/* loaded from: classes.dex */
public interface y {
    void a(p pVar, int i2);

    void b(p pVar, int i2, boolean z);
}
