package com.google.android.datatransport.runtime.scheduling.jobscheduling;
/* loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ a f1001e = new a();

    private /* synthetic */ a() {
    }

    @Override // java.lang.Runnable
    public final void run() {
        AlarmManagerSchedulerBroadcastReceiver.a();
    }
}
