package com.google.android.datatransport.runtime.backends;

import f.b.a.a.i.j;
/* loaded from: classes.dex */
public interface m {
    j a(j jVar);

    g b(f fVar);
}
