package com.google.android.datatransport.runtime.backends;

import android.content.Context;
import f.b.a.a.i.c0.a;
/* loaded from: classes.dex */
class i {
    private final Context a;
    private final a b;
    private final a c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public i(Context context, a aVar, a aVar2) {
        this.a = context;
        this.b = aVar;
        this.c = aVar2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public h a(String str) {
        return h.a(this.a, this.b, this.c, str);
    }
}
