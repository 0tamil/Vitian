package com.google.android.datatransport.runtime.backends;
/* loaded from: classes.dex */
public interface d {
    m create(h hVar);
}
