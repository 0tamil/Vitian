package com.google.android.datatransport.runtime.backends;
/* loaded from: classes.dex */
public interface e {
    m a(String str);
}
