package com.google.android.datatransport.cct;

import com.google.android.datatransport.cct.d;
import f.b.a.a.i.z.c;
/* loaded from: classes.dex */
public final /* synthetic */ class a implements c {
    public static final /* synthetic */ a a = new a();

    private /* synthetic */ a() {
    }

    @Override // f.b.a.a.i.z.c
    public final Object a(Object obj, Object obj2) {
        return d.k((d.a) obj, (d.b) obj2);
    }
}
