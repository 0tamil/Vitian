package com.google.android.datatransport.cct.f;
/* loaded from: classes.dex */
public final class b implements com.google.firebase.n.h.a {
    public static final com.google.firebase.n.h.a a = new b();

    /* loaded from: classes.dex */
    private static final class a implements com.google.firebase.n.d<com.google.android.datatransport.cct.f.a> {
        static final a a = new a();
        private static final com.google.firebase.n.c b = com.google.firebase.n.c.d("sdkVersion");
        private static final com.google.firebase.n.c c = com.google.firebase.n.c.d("model");

        /* renamed from: d  reason: collision with root package name */
        private static final com.google.firebase.n.c f921d = com.google.firebase.n.c.d("hardware");

        /* renamed from: e  reason: collision with root package name */
        private static final com.google.firebase.n.c f922e = com.google.firebase.n.c.d("device");

        /* renamed from: f  reason: collision with root package name */
        private static final com.google.firebase.n.c f923f = com.google.firebase.n.c.d("product");

        /* renamed from: g  reason: collision with root package name */
        private static final com.google.firebase.n.c f924g = com.google.firebase.n.c.d("osBuild");

        /* renamed from: h  reason: collision with root package name */
        private static final com.google.firebase.n.c f925h = com.google.firebase.n.c.d("manufacturer");

        /* renamed from: i  reason: collision with root package name */
        private static final com.google.firebase.n.c f926i = com.google.firebase.n.c.d("fingerprint");

        /* renamed from: j  reason: collision with root package name */
        private static final com.google.firebase.n.c f927j = com.google.firebase.n.c.d("locale");

        /* renamed from: k  reason: collision with root package name */
        private static final com.google.firebase.n.c f928k = com.google.firebase.n.c.d("country");
        private static final com.google.firebase.n.c l = com.google.firebase.n.c.d("mccMnc");
        private static final com.google.firebase.n.c m = com.google.firebase.n.c.d("applicationBuild");

        private a() {
        }

        /* renamed from: b */
        public void a(com.google.android.datatransport.cct.f.a aVar, com.google.firebase.n.e eVar) {
            eVar.f(b, aVar.m());
            eVar.f(c, aVar.j());
            eVar.f(f921d, aVar.f());
            eVar.f(f922e, aVar.d());
            eVar.f(f923f, aVar.l());
            eVar.f(f924g, aVar.k());
            eVar.f(f925h, aVar.h());
            eVar.f(f926i, aVar.e());
            eVar.f(f927j, aVar.g());
            eVar.f(f928k, aVar.c());
            eVar.f(l, aVar.i());
            eVar.f(m, aVar.b());
        }
    }

    /* renamed from: com.google.android.datatransport.cct.f.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    private static final class C0024b implements com.google.firebase.n.d<j> {
        static final C0024b a = new C0024b();
        private static final com.google.firebase.n.c b = com.google.firebase.n.c.d("logRequest");

        private C0024b() {
        }

        /* renamed from: b */
        public void a(j jVar, com.google.firebase.n.e eVar) {
            eVar.f(b, jVar.c());
        }
    }

    /* loaded from: classes.dex */
    private static final class c implements com.google.firebase.n.d<k> {
        static final c a = new c();
        private static final com.google.firebase.n.c b = com.google.firebase.n.c.d("clientType");
        private static final com.google.firebase.n.c c = com.google.firebase.n.c.d("androidClientInfo");

        private c() {
        }

        /* renamed from: b */
        public void a(k kVar, com.google.firebase.n.e eVar) {
            eVar.f(b, kVar.c());
            eVar.f(c, kVar.b());
        }
    }

    /* loaded from: classes.dex */
    private static final class d implements com.google.firebase.n.d<l> {
        static final d a = new d();
        private static final com.google.firebase.n.c b = com.google.firebase.n.c.d("eventTimeMs");
        private static final com.google.firebase.n.c c = com.google.firebase.n.c.d("eventCode");

        /* renamed from: d  reason: collision with root package name */
        private static final com.google.firebase.n.c f929d = com.google.firebase.n.c.d("eventUptimeMs");

        /* renamed from: e  reason: collision with root package name */
        private static final com.google.firebase.n.c f930e = com.google.firebase.n.c.d("sourceExtension");

        /* renamed from: f  reason: collision with root package name */
        private static final com.google.firebase.n.c f931f = com.google.firebase.n.c.d("sourceExtensionJsonProto3");

        /* renamed from: g  reason: collision with root package name */
        private static final com.google.firebase.n.c f932g = com.google.firebase.n.c.d("timezoneOffsetSeconds");

        /* renamed from: h  reason: collision with root package name */
        private static final com.google.firebase.n.c f933h = com.google.firebase.n.c.d("networkConnectionInfo");

        private d() {
        }

        /* renamed from: b */
        public void a(l lVar, com.google.firebase.n.e eVar) {
            eVar.d(b, lVar.c());
            eVar.f(c, lVar.b());
            eVar.d(f929d, lVar.d());
            eVar.f(f930e, lVar.f());
            eVar.f(f931f, lVar.g());
            eVar.d(f932g, lVar.h());
            eVar.f(f933h, lVar.e());
        }
    }

    /* loaded from: classes.dex */
    private static final class e implements com.google.firebase.n.d<m> {
        static final e a = new e();
        private static final com.google.firebase.n.c b = com.google.firebase.n.c.d("requestTimeMs");
        private static final com.google.firebase.n.c c = com.google.firebase.n.c.d("requestUptimeMs");

        /* renamed from: d  reason: collision with root package name */
        private static final com.google.firebase.n.c f934d = com.google.firebase.n.c.d("clientInfo");

        /* renamed from: e  reason: collision with root package name */
        private static final com.google.firebase.n.c f935e = com.google.firebase.n.c.d("logSource");

        /* renamed from: f  reason: collision with root package name */
        private static final com.google.firebase.n.c f936f = com.google.firebase.n.c.d("logSourceName");

        /* renamed from: g  reason: collision with root package name */
        private static final com.google.firebase.n.c f937g = com.google.firebase.n.c.d("logEvent");

        /* renamed from: h  reason: collision with root package name */
        private static final com.google.firebase.n.c f938h = com.google.firebase.n.c.d("qosTier");

        private e() {
        }

        /* renamed from: b */
        public void a(m mVar, com.google.firebase.n.e eVar) {
            eVar.d(b, mVar.g());
            eVar.d(c, mVar.h());
            eVar.f(f934d, mVar.b());
            eVar.f(f935e, mVar.d());
            eVar.f(f936f, mVar.e());
            eVar.f(f937g, mVar.c());
            eVar.f(f938h, mVar.f());
        }
    }

    /* loaded from: classes.dex */
    private static final class f implements com.google.firebase.n.d<o> {
        static final f a = new f();
        private static final com.google.firebase.n.c b = com.google.firebase.n.c.d("networkType");
        private static final com.google.firebase.n.c c = com.google.firebase.n.c.d("mobileSubtype");

        private f() {
        }

        /* renamed from: b */
        public void a(o oVar, com.google.firebase.n.e eVar) {
            eVar.f(b, oVar.c());
            eVar.f(c, oVar.b());
        }
    }

    private b() {
    }

    @Override // com.google.firebase.n.h.a
    public void a(com.google.firebase.n.h.b<?> bVar) {
        C0024b bVar2 = C0024b.a;
        bVar.a(j.class, bVar2);
        bVar.a(com.google.android.datatransport.cct.f.d.class, bVar2);
        e eVar = e.a;
        bVar.a(m.class, eVar);
        bVar.a(g.class, eVar);
        c cVar = c.a;
        bVar.a(k.class, cVar);
        bVar.a(com.google.android.datatransport.cct.f.e.class, cVar);
        a aVar = a.a;
        bVar.a(com.google.android.datatransport.cct.f.a.class, aVar);
        bVar.a(com.google.android.datatransport.cct.f.c.class, aVar);
        d dVar = d.a;
        bVar.a(l.class, dVar);
        bVar.a(com.google.android.datatransport.cct.f.f.class, dVar);
        f fVar = f.a;
        bVar.a(o.class, fVar);
        bVar.a(i.class, fVar);
    }
}
