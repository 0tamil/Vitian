package com.google.android.datatransport.cct.f;

import com.google.android.datatransport.cct.f.a;
/* loaded from: classes.dex */
final class c extends com.google.android.datatransport.cct.f.a {
    private final Integer a;
    private final String b;
    private final String c;

    /* renamed from: d  reason: collision with root package name */
    private final String f939d;

    /* renamed from: e  reason: collision with root package name */
    private final String f940e;

    /* renamed from: f  reason: collision with root package name */
    private final String f941f;

    /* renamed from: g  reason: collision with root package name */
    private final String f942g;

    /* renamed from: h  reason: collision with root package name */
    private final String f943h;

    /* renamed from: i  reason: collision with root package name */
    private final String f944i;

    /* renamed from: j  reason: collision with root package name */
    private final String f945j;

    /* renamed from: k  reason: collision with root package name */
    private final String f946k;
    private final String l;

    /* loaded from: classes.dex */
    static final class b extends a.AbstractC0023a {
        private Integer a;
        private String b;
        private String c;

        /* renamed from: d  reason: collision with root package name */
        private String f947d;

        /* renamed from: e  reason: collision with root package name */
        private String f948e;

        /* renamed from: f  reason: collision with root package name */
        private String f949f;

        /* renamed from: g  reason: collision with root package name */
        private String f950g;

        /* renamed from: h  reason: collision with root package name */
        private String f951h;

        /* renamed from: i  reason: collision with root package name */
        private String f952i;

        /* renamed from: j  reason: collision with root package name */
        private String f953j;

        /* renamed from: k  reason: collision with root package name */
        private String f954k;
        private String l;

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public com.google.android.datatransport.cct.f.a a() {
            return new c(this.a, this.b, this.c, this.f947d, this.f948e, this.f949f, this.f950g, this.f951h, this.f952i, this.f953j, this.f954k, this.l);
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a b(String str) {
            this.l = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a c(String str) {
            this.f953j = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a d(String str) {
            this.f947d = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a e(String str) {
            this.f951h = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a f(String str) {
            this.c = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a g(String str) {
            this.f952i = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a h(String str) {
            this.f950g = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a i(String str) {
            this.f954k = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a j(String str) {
            this.b = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a k(String str) {
            this.f949f = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a l(String str) {
            this.f948e = str;
            return this;
        }

        @Override // com.google.android.datatransport.cct.f.a.AbstractC0023a
        public a.AbstractC0023a m(Integer num) {
            this.a = num;
            return this;
        }
    }

    private c(Integer num, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11) {
        this.a = num;
        this.b = str;
        this.c = str2;
        this.f939d = str3;
        this.f940e = str4;
        this.f941f = str5;
        this.f942g = str6;
        this.f943h = str7;
        this.f944i = str8;
        this.f945j = str9;
        this.f946k = str10;
        this.l = str11;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String b() {
        return this.l;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String c() {
        return this.f945j;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String d() {
        return this.f939d;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String e() {
        return this.f943h;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof com.google.android.datatransport.cct.f.a)) {
            return false;
        }
        com.google.android.datatransport.cct.f.a aVar = (com.google.android.datatransport.cct.f.a) obj;
        Integer num = this.a;
        if (num != null ? num.equals(aVar.m()) : aVar.m() == null) {
            String str = this.b;
            if (str != null ? str.equals(aVar.j()) : aVar.j() == null) {
                String str2 = this.c;
                if (str2 != null ? str2.equals(aVar.f()) : aVar.f() == null) {
                    String str3 = this.f939d;
                    if (str3 != null ? str3.equals(aVar.d()) : aVar.d() == null) {
                        String str4 = this.f940e;
                        if (str4 != null ? str4.equals(aVar.l()) : aVar.l() == null) {
                            String str5 = this.f941f;
                            if (str5 != null ? str5.equals(aVar.k()) : aVar.k() == null) {
                                String str6 = this.f942g;
                                if (str6 != null ? str6.equals(aVar.h()) : aVar.h() == null) {
                                    String str7 = this.f943h;
                                    if (str7 != null ? str7.equals(aVar.e()) : aVar.e() == null) {
                                        String str8 = this.f944i;
                                        if (str8 != null ? str8.equals(aVar.g()) : aVar.g() == null) {
                                            String str9 = this.f945j;
                                            if (str9 != null ? str9.equals(aVar.c()) : aVar.c() == null) {
                                                String str10 = this.f946k;
                                                if (str10 != null ? str10.equals(aVar.i()) : aVar.i() == null) {
                                                    String str11 = this.l;
                                                    String b2 = aVar.b();
                                                    if (str11 == null) {
                                                        if (b2 == null) {
                                                            return true;
                                                        }
                                                    } else if (str11.equals(b2)) {
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String f() {
        return this.c;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String g() {
        return this.f944i;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String h() {
        return this.f942g;
    }

    public int hashCode() {
        Integer num = this.a;
        int i2 = 0;
        int hashCode = ((num == null ? 0 : num.hashCode()) ^ 1000003) * 1000003;
        String str = this.b;
        int hashCode2 = (hashCode ^ (str == null ? 0 : str.hashCode())) * 1000003;
        String str2 = this.c;
        int hashCode3 = (hashCode2 ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.f939d;
        int hashCode4 = (hashCode3 ^ (str3 == null ? 0 : str3.hashCode())) * 1000003;
        String str4 = this.f940e;
        int hashCode5 = (hashCode4 ^ (str4 == null ? 0 : str4.hashCode())) * 1000003;
        String str5 = this.f941f;
        int hashCode6 = (hashCode5 ^ (str5 == null ? 0 : str5.hashCode())) * 1000003;
        String str6 = this.f942g;
        int hashCode7 = (hashCode6 ^ (str6 == null ? 0 : str6.hashCode())) * 1000003;
        String str7 = this.f943h;
        int hashCode8 = (hashCode7 ^ (str7 == null ? 0 : str7.hashCode())) * 1000003;
        String str8 = this.f944i;
        int hashCode9 = (hashCode8 ^ (str8 == null ? 0 : str8.hashCode())) * 1000003;
        String str9 = this.f945j;
        int hashCode10 = (hashCode9 ^ (str9 == null ? 0 : str9.hashCode())) * 1000003;
        String str10 = this.f946k;
        int hashCode11 = (hashCode10 ^ (str10 == null ? 0 : str10.hashCode())) * 1000003;
        String str11 = this.l;
        if (str11 != null) {
            i2 = str11.hashCode();
        }
        return hashCode11 ^ i2;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String i() {
        return this.f946k;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String j() {
        return this.b;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String k() {
        return this.f941f;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public String l() {
        return this.f940e;
    }

    @Override // com.google.android.datatransport.cct.f.a
    public Integer m() {
        return this.a;
    }

    public String toString() {
        return "AndroidClientInfo{sdkVersion=" + this.a + ", model=" + this.b + ", hardware=" + this.c + ", device=" + this.f939d + ", product=" + this.f940e + ", osBuild=" + this.f941f + ", manufacturer=" + this.f942g + ", fingerprint=" + this.f943h + ", locale=" + this.f944i + ", country=" + this.f945j + ", mccMnc=" + this.f946k + ", applicationBuild=" + this.l + "}";
    }
}
