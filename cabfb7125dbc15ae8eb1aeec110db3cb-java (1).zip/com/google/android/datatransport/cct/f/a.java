package com.google.android.datatransport.cct.f;

import com.google.android.datatransport.cct.f.c;
import com.google.auto.value.AutoValue;
@AutoValue
/* loaded from: classes.dex */
public abstract class a {

    @AutoValue.Builder
    /* renamed from: com.google.android.datatransport.cct.f.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static abstract class AbstractC0023a {
        public abstract a a();

        public abstract AbstractC0023a b(String str);

        public abstract AbstractC0023a c(String str);

        public abstract AbstractC0023a d(String str);

        public abstract AbstractC0023a e(String str);

        public abstract AbstractC0023a f(String str);

        public abstract AbstractC0023a g(String str);

        public abstract AbstractC0023a h(String str);

        public abstract AbstractC0023a i(String str);

        public abstract AbstractC0023a j(String str);

        public abstract AbstractC0023a k(String str);

        public abstract AbstractC0023a l(String str);

        public abstract AbstractC0023a m(Integer num);
    }

    public static AbstractC0023a a() {
        return new c.b();
    }

    public abstract String b();

    public abstract String c();

    public abstract String d();

    public abstract String e();

    public abstract String f();

    public abstract String g();

    public abstract String h();

    public abstract String i();

    public abstract String j();

    public abstract String k();

    public abstract String l();

    public abstract Integer m();
}
