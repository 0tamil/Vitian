package com.google.android.gms.common;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class w {
    static final t[] a = {x.a, x.b};
}
