package com.google.android.gms.common;
/* loaded from: classes.dex */
public final class i {

    /* renamed from: a */
    public static final int a_res_0x7f0e0025 = 2131623973;
}
