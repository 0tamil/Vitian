package com.google.android.gms.common.api;

import com.google.android.gms.common.api.j;
/* loaded from: classes.dex */
public abstract class n<R extends j> {
}
