package com.google.android.gms.common.api;

import com.google.android.gms.common.api.j;
/* loaded from: classes.dex */
public interface k<R extends j> {
    void a(R r);
}
