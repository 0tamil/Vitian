package com.google.android.gms.common.api;

import com.google.android.gms.common.api.j;
/* loaded from: classes.dex */
public abstract class g<R extends j> {

    /* loaded from: classes.dex */
    public interface a {
        void a(Status status);
    }

    public abstract void b(a aVar);

    public abstract void c(k<? super R> kVar);
}
