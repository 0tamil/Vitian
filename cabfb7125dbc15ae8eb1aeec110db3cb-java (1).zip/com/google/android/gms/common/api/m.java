package com.google.android.gms.common.api;

import com.google.android.gms.common.api.j;
/* loaded from: classes.dex */
public abstract class m<R extends j, S extends j> {
    public Status a(Status status) {
        return status;
    }

    public abstract g<S> b(R r);
}
