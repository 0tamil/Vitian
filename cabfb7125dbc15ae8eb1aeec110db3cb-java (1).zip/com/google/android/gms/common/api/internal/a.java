package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.b;
/* loaded from: classes.dex */
public class a implements q {
    @Override // com.google.android.gms.common.api.internal.q
    public final Exception a(Status status) {
        return b.a(status);
    }
}
