package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.a;
/* loaded from: classes.dex */
final class f0 extends w0 {
    final /* synthetic */ a b;
    final /* synthetic */ h0 c;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f0(h0 h0Var, v0 v0Var, a aVar) {
        super(v0Var);
        this.c = h0Var;
        this.b = aVar;
    }

    @Override // com.google.android.gms.common.api.internal.w0
    public final void a() {
        this.c.f1124g.l(this.b);
    }
}
