package com.google.android.gms.common.api.internal;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class a0 extends w0 {
    final /* synthetic */ c0 b;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a0(c0 c0Var, v0 v0Var) {
        super(v0Var);
        this.b = c0Var;
    }

    @Override // com.google.android.gms.common.api.internal.w0
    public final void a() {
        this.b.f(1);
    }
}
