package com.google.android.gms.common.api.internal;
/* loaded from: classes.dex */
final class b0 extends w0 {
    final /* synthetic */ c0 b;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b0(c0 c0Var, v0 v0Var) {
        super(v0Var);
        this.b = c0Var;
    }

    @Override // com.google.android.gms.common.api.internal.w0
    public final void a() {
        y0 y0Var;
        y0Var = this.b.a;
        y0Var.n.a(null);
    }
}
