package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.a;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.j;
import java.util.Set;
/* loaded from: classes.dex */
public interface b2 {
    void b(j jVar, Set<Scope> set);

    void c(a aVar);
}
