package com.google.android.gms.common.api.internal;
/* loaded from: classes.dex */
public interface e<R> {
    void a(R r);
}
