package com.google.android.gms.common.api.internal;

import android.os.Bundle;
/* loaded from: classes.dex */
public interface f {
    void b(int i2);

    void d(Bundle bundle);
}
