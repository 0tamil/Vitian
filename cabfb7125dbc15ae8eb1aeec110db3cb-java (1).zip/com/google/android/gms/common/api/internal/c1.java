package com.google.android.gms.common.api.internal;
/* loaded from: classes.dex */
final class c1 implements Runnable {

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ g1 f1087e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c1(g1 g1Var) {
        this.f1087e = g1Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f1087e.j();
    }
}
