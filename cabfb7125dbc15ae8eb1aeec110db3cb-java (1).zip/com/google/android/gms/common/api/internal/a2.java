package com.google.android.gms.common.api.internal;

import f.b.a.b.e.b.l;
/* loaded from: classes.dex */
final class a2 implements Runnable {

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ l f1079e;

    /* renamed from: f  reason: collision with root package name */
    final /* synthetic */ c2 f1080f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a2(c2 c2Var, l lVar) {
        this.f1080f = c2Var;
        this.f1079e = lVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        c2.T(this.f1080f, this.f1079e);
    }
}
