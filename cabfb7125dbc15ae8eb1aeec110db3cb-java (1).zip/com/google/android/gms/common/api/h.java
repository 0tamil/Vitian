package com.google.android.gms.common.api;
/* loaded from: classes.dex */
public interface h {
    void a();
}
