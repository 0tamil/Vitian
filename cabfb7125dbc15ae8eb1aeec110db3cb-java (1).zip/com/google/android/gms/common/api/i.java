package com.google.android.gms.common.api;
/* loaded from: classes.dex */
public class i extends b {
    public i(Status status) {
        super(status);
    }
}
