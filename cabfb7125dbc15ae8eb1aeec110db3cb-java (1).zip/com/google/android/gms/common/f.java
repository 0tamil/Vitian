package com.google.android.gms.common;

import android.content.Context;
import android.content.res.Resources;
/* loaded from: classes.dex */
public final class f extends g {
    public static Resources c(Context context) {
        return g.c(context);
    }
}
