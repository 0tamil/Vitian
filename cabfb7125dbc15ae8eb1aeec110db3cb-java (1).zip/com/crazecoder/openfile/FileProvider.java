package com.crazecoder.openfile;
/* loaded from: classes.dex */
public class FileProvider extends androidx.core.content.FileProvider {
}
