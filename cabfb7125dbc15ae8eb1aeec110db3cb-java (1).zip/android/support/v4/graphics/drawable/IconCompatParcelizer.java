package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.b;
/* loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(b bVar) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(bVar);
    }

    public static void write(IconCompat iconCompat, b bVar) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, bVar);
    }
}
