package android.support.v4.media.session;

import androidx.media.AudioAttributesCompat;
/* loaded from: classes.dex */
public final class d {
    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public d(int i2, int i3, int i4, int i5, int i6) {
        this(i2, r0.a(), i4, i5, i6);
        AudioAttributesCompat.a aVar = new AudioAttributesCompat.a();
        aVar.b(i3);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(int i2, AudioAttributesCompat audioAttributesCompat, int i3, int i4, int i5) {
    }
}
