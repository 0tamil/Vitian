package android.support.v4.media;

import androidx.media.AudioAttributesImplApi21;
import androidx.versionedparcelable.b;
/* loaded from: classes.dex */
public final class AudioAttributesImplApi21Parcelizer extends androidx.media.AudioAttributesImplApi21Parcelizer {
    public static AudioAttributesImplApi21 read(b bVar) {
        return androidx.media.AudioAttributesImplApi21Parcelizer.read(bVar);
    }

    public static void write(AudioAttributesImplApi21 audioAttributesImplApi21, b bVar) {
        androidx.media.AudioAttributesImplApi21Parcelizer.write(audioAttributesImplApi21, bVar);
    }
}
