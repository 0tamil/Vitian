package androidx.appcompat.view.menu;

import android.widget.ListView;
/* loaded from: classes.dex */
public interface p {
    void a();

    boolean c();

    void dismiss();

    ListView k();
}
