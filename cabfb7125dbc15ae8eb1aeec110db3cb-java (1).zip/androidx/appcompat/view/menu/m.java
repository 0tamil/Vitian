package androidx.appcompat.view.menu;

import android.content.Context;
/* loaded from: classes.dex */
public interface m {

    /* loaded from: classes.dex */
    public interface a {
        void b(g gVar, boolean z);

        boolean c(g gVar);
    }

    void b(g gVar, boolean z);

    boolean d();

    void e(Context context, g gVar);

    boolean f(g gVar, i iVar);

    boolean g(g gVar, i iVar);

    void h(a aVar);

    boolean i(r rVar);

    void j(boolean z);
}
