package androidx.appcompat.view.menu;
/* loaded from: classes.dex */
public interface n {

    /* loaded from: classes.dex */
    public interface a {
        boolean c();

        void d(i iVar, int i2);

        i getItemData();
    }

    void b(g gVar);
}
