package androidx.appcompat.app;

import e.a.n.b;
/* loaded from: classes.dex */
public interface d {
    void f(b bVar);

    void h(b bVar);

    b k(b.a aVar);
}
