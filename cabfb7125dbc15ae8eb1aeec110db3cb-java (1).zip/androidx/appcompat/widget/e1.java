package androidx.appcompat.widget;
/* loaded from: classes.dex */
public interface e1 {
    CharSequence a();
}
