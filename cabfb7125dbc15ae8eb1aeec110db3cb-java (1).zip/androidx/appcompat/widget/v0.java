package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
/* loaded from: classes.dex */
public class v0 {
    public ColorStateList a;
    public PorterDuff.Mode b;
    public boolean c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f489d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a() {
        this.a = null;
        this.f489d = false;
        this.b = null;
        this.c = false;
    }
}
