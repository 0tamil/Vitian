package androidx.appcompat.widget;

import android.graphics.Rect;
/* loaded from: classes.dex */
public interface h0 {

    /* loaded from: classes.dex */
    public interface a {
        void a(Rect rect);
    }

    void setOnFitSystemWindowsListener(a aVar);
}
