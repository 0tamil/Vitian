package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.g;
/* loaded from: classes.dex */
public interface l0 {
    void f(g gVar, MenuItem menuItem);

    void h(g gVar, MenuItem menuItem);
}
