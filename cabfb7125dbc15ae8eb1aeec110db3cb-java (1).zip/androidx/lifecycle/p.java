package androidx.lifecycle;

import androidx.savedstate.SavedStateRegistry;
/* loaded from: classes.dex */
public final class p {
    /* JADX INFO: Access modifiers changed from: package-private */
    public SavedStateRegistry.b a() {
        throw null;
    }
}
