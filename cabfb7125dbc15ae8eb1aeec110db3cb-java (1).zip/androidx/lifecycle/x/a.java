package androidx.lifecycle.x;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a */
    public static final int a_res_0x7f0800c7 = 2131230919;
}
