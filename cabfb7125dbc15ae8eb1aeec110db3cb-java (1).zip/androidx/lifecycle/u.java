package androidx.lifecycle;

import android.view.View;
import androidx.lifecycle.w.a;
/* loaded from: classes.dex */
public class u {
    public static void a(View view, g gVar) {
        view.setTag(a.a_res_0x7f0800c5, gVar);
    }
}
