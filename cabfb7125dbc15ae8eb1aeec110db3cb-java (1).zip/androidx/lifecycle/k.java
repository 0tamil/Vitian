package androidx.lifecycle;

import java.util.HashMap;
/* loaded from: classes.dex */
public class k {
    public k() {
        new HashMap();
    }
}
