package androidx.lifecycle;
/* loaded from: classes.dex */
public interface t {
    s g();
}
