package androidx.lifecycle;
/* loaded from: classes.dex */
public interface m<T> {
    void a(T t);
}
