package androidx.lifecycle;

import androidx.lifecycle.d;
/* loaded from: classes.dex */
class Lifecycling$1 implements e {
    final /* synthetic */ e a;

    @Override // androidx.lifecycle.e
    public void d(g gVar, d.b bVar) {
        this.a.d(gVar, bVar);
    }
}
