package androidx.lifecycle;

import android.view.View;
import androidx.lifecycle.x.a;
/* loaded from: classes.dex */
public class v {
    public static void a(View view, t tVar) {
        view.setTag(a.a_res_0x7f0800c7, tVar);
    }
}
