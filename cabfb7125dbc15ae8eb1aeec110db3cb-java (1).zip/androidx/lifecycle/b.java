package androidx.lifecycle;
/* loaded from: classes.dex */
interface b extends f {
    void a(g gVar);

    void b(g gVar);

    void c(g gVar);

    void e(g gVar);

    void f(g gVar);

    void g(g gVar);
}
