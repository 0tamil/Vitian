package androidx.lifecycle;
@Deprecated
/* loaded from: classes.dex */
public interface i extends g {
    @Override // androidx.lifecycle.g
    h a();
}
