package androidx.media;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a */
    public static final int a_res_0x7f080027 = 2131230759;

    /* renamed from: b */
    public static final int b_res_0x7f080048 = 2131230792;

    /* renamed from: c */
    public static final int c_res_0x7f08005d = 2131230813;

    /* renamed from: d */
    public static final int d_res_0x7f080077 = 2131230839;
}
