package androidx.media;
/* loaded from: classes.dex */
public final class c {

    /* renamed from: a */
    public static final int a_res_0x7f0b001f = 2131427359;

    /* renamed from: b */
    public static final int b_res_0x7f0b0021 = 2131427361;

    /* renamed from: c */
    public static final int c_res_0x7f0b0023 = 2131427363;

    /* renamed from: d */
    public static final int d_res_0x7f0b0028 = 2131427368;
}
