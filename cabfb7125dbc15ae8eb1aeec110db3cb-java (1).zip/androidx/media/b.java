package androidx.media;
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a */
    public static final int a_res_0x7f090002 = 2131296258;
}
