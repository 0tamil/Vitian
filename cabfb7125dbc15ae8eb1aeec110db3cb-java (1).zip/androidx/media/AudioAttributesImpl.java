package androidx.media;

import androidx.versionedparcelable.d;
/* loaded from: classes.dex */
interface AudioAttributesImpl extends d {

    /* loaded from: classes.dex */
    public interface a {
        AudioAttributesImpl a();

        a b(int i2);
    }
}
