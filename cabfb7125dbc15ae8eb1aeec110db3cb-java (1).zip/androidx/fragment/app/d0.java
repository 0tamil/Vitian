package androidx.fragment.app;

import android.view.ViewGroup;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public interface d0 {
    c0 a(ViewGroup viewGroup);
}
