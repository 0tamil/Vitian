package androidx.fragment.app;

import android.os.Bundle;
/* loaded from: classes.dex */
public interface s {
    void a(String str, Bundle bundle);
}
