package androidx.fragment.app;
/* loaded from: classes.dex */
public interface r {
    void b(n nVar, Fragment fragment);
}
