package androidx.fragment.app;

import android.util.AndroidRuntimeException;
/* loaded from: classes.dex */
final class e0 extends AndroidRuntimeException {
    public e0(String str) {
        super(str);
    }
}
