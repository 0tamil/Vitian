package androidx.savedstate;

import android.view.View;
/* loaded from: classes.dex */
public final class d {
    public static void a(View view, c cVar) {
        view.setTag(a.a_res_0x7f0800c6, cVar);
    }
}
