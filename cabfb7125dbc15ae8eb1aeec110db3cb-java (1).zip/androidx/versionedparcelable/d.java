package androidx.versionedparcelable;
/* loaded from: classes.dex */
public interface d {
}
