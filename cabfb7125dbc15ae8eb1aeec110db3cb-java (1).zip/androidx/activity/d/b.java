package androidx.activity.d;

import android.content.Context;
/* loaded from: classes.dex */
public interface b {
    void a(Context context);
}
