package androidx.activity;

import androidx.lifecycle.g;
/* loaded from: classes.dex */
public interface c extends g {
    OnBackPressedDispatcher i();
}
