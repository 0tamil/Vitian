package androidx.activity.result;

import android.annotation.SuppressLint;
import androidx.core.app.b;
/* loaded from: classes.dex */
public abstract class c<I> {
    public void a(@SuppressLint({"UnknownNullness"}) I i2) {
        b(i2, null);
    }

    public abstract void b(@SuppressLint({"UnknownNullness"}) I i2, b bVar);

    public abstract void c();
}
