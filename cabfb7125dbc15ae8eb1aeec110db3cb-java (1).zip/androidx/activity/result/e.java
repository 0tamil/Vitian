package androidx.activity.result;
/* loaded from: classes.dex */
public interface e {
    d c();
}
