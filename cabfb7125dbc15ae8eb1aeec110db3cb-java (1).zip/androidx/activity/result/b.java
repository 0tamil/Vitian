package androidx.activity.result;

import android.annotation.SuppressLint;
/* loaded from: classes.dex */
public interface b<O> {
    void a(@SuppressLint({"UnknownNullness"}) O o);
}
