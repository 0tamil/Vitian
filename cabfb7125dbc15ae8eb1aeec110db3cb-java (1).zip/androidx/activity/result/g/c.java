package androidx.activity.result.g;

import android.content.Context;
import android.content.Intent;
import androidx.activity.result.a;
/* loaded from: classes.dex */
public final class c extends a<Intent, a> {
    @Override // androidx.activity.result.g.a
    public /* bridge */ /* synthetic */ Intent a(Context context, Intent intent) {
        Intent intent2 = intent;
        d(context, intent2);
        return intent2;
    }

    public Intent d(Context context, Intent intent) {
        return intent;
    }

    /* renamed from: e */
    public a c(int i2, Intent intent) {
        return new a(i2, intent);
    }
}
