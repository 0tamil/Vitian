package androidx.window.layout;
/* loaded from: classes.dex */
public interface WindowInfoTrackerDecorator {
    WindowInfoTracker decorate(WindowInfoTracker windowInfoTracker);
}
