package androidx.window.layout;

import j.x.c.l;
import j.x.d.i;
import j.x.d.j;
/* loaded from: classes.dex */
final class WindowMetricsCalculator$Companion$decorator$1 extends j implements l<WindowMetricsCalculator, WindowMetricsCalculator> {
    public static final WindowMetricsCalculator$Companion$decorator$1 INSTANCE = new WindowMetricsCalculator$Companion$decorator$1();

    WindowMetricsCalculator$Companion$decorator$1() {
        super(1);
    }

    public final WindowMetricsCalculator invoke(WindowMetricsCalculator windowMetricsCalculator) {
        i.d(windowMetricsCalculator, "it");
        return windowMetricsCalculator;
    }
}
