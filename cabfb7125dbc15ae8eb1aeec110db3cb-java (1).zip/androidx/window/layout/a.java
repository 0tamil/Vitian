package androidx.window.layout;

import java.util.concurrent.Executor;
/* loaded from: classes.dex */
public final /* synthetic */ class a implements Executor {

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ a f900e = new a();

    private /* synthetic */ a() {
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
