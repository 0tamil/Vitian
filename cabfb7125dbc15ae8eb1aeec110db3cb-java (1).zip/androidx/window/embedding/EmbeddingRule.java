package androidx.window.embedding;

import androidx.window.core.ExperimentalWindowApi;
@ExperimentalWindowApi
/* loaded from: classes.dex */
public abstract class EmbeddingRule {
}
