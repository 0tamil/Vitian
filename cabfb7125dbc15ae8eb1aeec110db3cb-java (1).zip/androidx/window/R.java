package androidx.window;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class attr {
        public static final int activityAction = 0x7f030023;
        public static final int activityName = 0x7f030025;
        public static final int alwaysExpand = 0x7f03002d;
        public static final int clearTop = 0x7f03004e;
        public static final int finishPrimaryWithSecondary = 0x7f030084;
        public static final int finishSecondaryWithPrimary = 0x7f030085;
        public static final int placeholderActivityName = 0x7f0300d0;
        public static final int primaryActivityName = 0x7f0300d5;
        public static final int secondaryActivityAction = 0x7f0300e3;
        public static final int secondaryActivityName = 0x7f0300e4;
        public static final int splitLayoutDirection = 0x7f0300f1;
        public static final int splitMinSmallestWidth = 0x7f0300f2;
        public static final int splitMinWidth = 0x7f0300f3;
        public static final int splitRatio = 0x7f0300f4;

        private attr() {
        }
    }

    /* loaded from: classes.dex */
    public static final class id {
        public static final int androidx_window_activity_scope = 0x7f080041;
        public static final int locale = 0x7f080075;
        public static final int ltr = 0x7f080076;
        public static final int rtl = 0x7f08008a;

        private id() {
        }
    }

    /* loaded from: classes.dex */
    public static final class styleable {
        public static final int ActivityFilter_activityAction = 0x00000000;
        public static final int ActivityFilter_activityName = 0x00000001;
        public static final int ActivityRule_alwaysExpand = 0x00000000;
        public static final int SplitPairFilter_primaryActivityName = 0x00000000;
        public static final int SplitPairFilter_secondaryActivityAction = 0x00000001;
        public static final int SplitPairFilter_secondaryActivityName = 0x00000002;
        public static final int SplitPairRule_clearTop = 0x00000000;
        public static final int SplitPairRule_finishPrimaryWithSecondary = 0x00000001;
        public static final int SplitPairRule_finishSecondaryWithPrimary = 0x00000002;
        public static final int SplitPairRule_splitLayoutDirection = 0x00000003;
        public static final int SplitPairRule_splitMinSmallestWidth = 0x00000004;
        public static final int SplitPairRule_splitMinWidth = 0x00000005;
        public static final int SplitPairRule_splitRatio = 0x00000006;
        public static final int SplitPlaceholderRule_placeholderActivityName = 0x00000000;
        public static final int SplitPlaceholderRule_splitLayoutDirection = 0x00000001;
        public static final int SplitPlaceholderRule_splitMinSmallestWidth = 0x00000002;
        public static final int SplitPlaceholderRule_splitMinWidth = 0x00000003;
        public static final int SplitPlaceholderRule_splitRatio = 0x00000004;
        public static final int[] ActivityFilter = {edu.vit.vtop.androidapp.R.attr.activityAction, edu.vit.vtop.androidapp.R.attr.activityName};
        public static final int[] ActivityRule = {edu.vit.vtop.androidapp.R.attr.alwaysExpand};
        public static final int[] SplitPairFilter = {edu.vit.vtop.androidapp.R.attr.primaryActivityName, edu.vit.vtop.androidapp.R.attr.secondaryActivityAction, edu.vit.vtop.androidapp.R.attr.secondaryActivityName};
        public static final int[] SplitPairRule = {edu.vit.vtop.androidapp.R.attr.clearTop, edu.vit.vtop.androidapp.R.attr.finishPrimaryWithSecondary, edu.vit.vtop.androidapp.R.attr.finishSecondaryWithPrimary, edu.vit.vtop.androidapp.R.attr.splitLayoutDirection, edu.vit.vtop.androidapp.R.attr.splitMinSmallestWidth, edu.vit.vtop.androidapp.R.attr.splitMinWidth, edu.vit.vtop.androidapp.R.attr.splitRatio};
        public static final int[] SplitPlaceholderRule = {edu.vit.vtop.androidapp.R.attr.placeholderActivityName, edu.vit.vtop.androidapp.R.attr.splitLayoutDirection, edu.vit.vtop.androidapp.R.attr.splitMinSmallestWidth, edu.vit.vtop.androidapp.R.attr.splitMinWidth, edu.vit.vtop.androidapp.R.attr.splitRatio};

        private styleable() {
        }
    }

    private R() {
    }
}
