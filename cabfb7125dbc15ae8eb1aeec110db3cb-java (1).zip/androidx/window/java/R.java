package androidx.window.java;
/* loaded from: classes.dex */
public final class R {
    private R() {
    }
}
