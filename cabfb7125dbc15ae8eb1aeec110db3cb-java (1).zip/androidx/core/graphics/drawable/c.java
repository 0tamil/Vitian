package androidx.core.graphics.drawable;

import android.graphics.drawable.Drawable;
/* loaded from: classes.dex */
public interface c {
    Drawable a();

    void b(Drawable drawable);
}
