package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.d;
/* loaded from: classes.dex */
public final class RemoteActionCompat implements d {
    public IconCompat a;
    public CharSequence b;
    public CharSequence c;

    /* renamed from: d  reason: collision with root package name */
    public PendingIntent f537d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f538e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f539f;
}
