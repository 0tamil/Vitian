package androidx.core.app;

import android.os.Bundle;
/* loaded from: classes.dex */
public class b {
    public Bundle a() {
        throw null;
    }
}
