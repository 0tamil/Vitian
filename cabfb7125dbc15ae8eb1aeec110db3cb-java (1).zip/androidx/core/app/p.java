package androidx.core.app;

import android.view.View;
import java.util.List;
import java.util.Map;
/* loaded from: classes.dex */
public abstract class p {
    public abstract void a(List<String> list, Map<String, View> map);

    public abstract void b(List<String> list, List<View> list2, List<View> list3);

    public abstract void c(List<String> list, List<View> list2, List<View> list3);
}
