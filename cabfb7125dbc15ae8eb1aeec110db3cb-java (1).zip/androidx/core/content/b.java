package androidx.core.content;

import android.content.LocusId;
/* loaded from: classes.dex */
public final class b {
    public LocusId a() {
        throw null;
    }
}
